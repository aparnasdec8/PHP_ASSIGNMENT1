﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Samplemvcapp.Models
{
    public class mvc
    {
        [Required(ErrorMessage="can't be  empty")]
        [Display(Name="Student name")]

        public string sname { get; set; }
        [Required(ErrorMessage = "can't be  empty")]
        [Display(Name = "Address")]
        [DataType (DataType.MultilineText)]
        
        public string address { get; set; }
        [Required(ErrorMessage = "can't be  empty")]
        [Display(Name = "Gender")]
        [DataType(DataType.EmailAddress)]
        public Gender genderlist{ get; set; }
        public string email { get; set; }
    }
    public enum Gender
    {
        Male,
        Female
    }
}